import 'package:flutter/material.dart';
import 'package:prac2_iem/domain/ Image_Post.dart';
import '../model/modelo_imagen_local.dart';
import '../shared/local_image_posts.dart';

class DiscoverProvider extends ChangeNotifier {
  List<ImagePost> _imagePosts = [];
  bool _isLoading = false;
  int _imagePosition = 0;

  List<ImagePost> get imagePost => _imagePosts;

  bool get isLoading => _isLoading;

  int get imagePosition => _imagePosition;

  /// Carga la lista de imagenes
  ///
  /// @return void
  cargaListaImagePosts() async {
    await Future.delayed(const Duration(seconds: 3));

    _imagePosts = imagePosts
        .map((map) => ModeloImagenLocal.fromMap(map).toImagePost())
        .toList();

    _isLoading = true;

    notifyListeners();
  }

  /// Actualiza la posicion de la imagen
  ///
  /// @param finalPosition
  void updatePosition(int finalPosition) {
    _imagePosition = finalPosition;
    notifyListeners();
  }
}
