List<Map<String, dynamic>> imagePosts = [
  {
    'name': 'Hamburguesa gourmet',
    'imgUrl': 'assets/images/1.jpg',
    'likes': 23230,
    'views': 1523,
  },
  {
    'name': 'Super Mario in the dark',
    'imgUrl': 'assets/images/2.jpg',
    'likes': 24230,
    'views': 1343,
  },
  {
    'name': '¿Mostrará piedad?',
    'imgUrl': 'assets/images/3.jpg',
    'likes': 21564320,
    'views': 123563,
  },
  {
    'name': '¡Ahí va, qué chorrazo!',
    'imgUrl': 'assets/images/4.jpg',
    'likes': 320,
    'views': 2300,
  },
  {
    'name': 'Pijama calentito',
    'imgUrl': 'assets/images/5.jpg',
    'likes': 3230,
    'views': 31030,
  },
  {
    'name': 'Pink sunset',
    'imgUrl': 'assets/images/6.jpg',
    'likes': 10,
    'views': 330,
  },
  {
    'name': 'Agaporni desemparejado',
    'imgUrl': 'assets/images/7.jpg',
    'likes': 1320,
    'views': 33032,
  },
  {
    'name': 'Fallas are coming',
    'imgUrl': 'assets/images/8.jpg',
    'likes': 342,
    'views': 3332,
  },

];