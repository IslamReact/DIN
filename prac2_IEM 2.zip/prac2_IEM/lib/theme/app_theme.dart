import 'package:flutter/material.dart';

class AppTheme{
  ThemeData appTheme(){
    return ThemeData(
      brightness: Brightness.dark,
    );
  }
}