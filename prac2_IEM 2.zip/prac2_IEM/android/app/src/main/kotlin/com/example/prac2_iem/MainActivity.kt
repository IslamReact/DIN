package com.example.prac2_iem

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
